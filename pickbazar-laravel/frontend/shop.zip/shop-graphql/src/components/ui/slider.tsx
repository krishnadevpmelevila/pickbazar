import "swiper/swiper-bundle.css";
import SwiperCore, { Navigation } from "swiper";
export { Swiper, SwiperSlide } from "swiper/react";
SwiperCore.use([Navigation]);
