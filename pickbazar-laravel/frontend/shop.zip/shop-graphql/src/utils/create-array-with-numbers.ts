export function createArrayWithNumbers(length: number) {
  return Array.from({ length }, (_, k) => k);
}
