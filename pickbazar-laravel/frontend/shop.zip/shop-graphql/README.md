<!-- 1. Type Menu
2. Search
3. Category Search
4. Add to Cart
5. Sidebar Cart
6. Offers New Design
7. Checkout Page
8. order page
9. Auth Pages
10. order details
11. Profile Page
12. Single Page
13. Single Page Modal

=========Overall Responsive Design===========
should avoid multiple default selection at address
what about orderstatuses paginator

# Customer Profile

1. ID [non-editable]
1. avatar
1. name
1. email [non-editable]
1. contact
1. address
1. bio
1. social[type, link]
1. status [is_active]
1. total order[may or mayn't be added]

To Do

1. [type].tsx page [n]
2. check search and category(category may need some work) [n]
3. authentications[basher vai]
4. add to cart issues [merin vai]
5. single page related product [need discuss][n]
6. profile page design[anik vai]
7. no data on your orders[anik vai]
8. where to put privacy and terms pages[need discussion]
9. checkout flow finish [all]
10. apply coupon component -->

1. home page limit incr(n) 30 [x]
2. category menu select(n)[x]
3. card responsive and function, font size
4. product details big issue on popup (done)
5. product type menu min-height (done)
6. add menu track order, FAQ, contact (n/b) [x]
7. demo user auto login
8. bakery page issues(n)[x]
9. contact page design
10. admin build and clean
