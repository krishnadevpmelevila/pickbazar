1. to run this project you need to setup your api endpoint at your `.env.local` file.
2. may need add your images cnd domain at `next.config.js` file.
3. may need some `tsconfig.json` change for your custom requirement.
4. sets your required site settings at `settings/site.setting.tsx` file.
5. adding custom icon

   TODO

- fix graphql query using partials(b/n)
- fix error messages through settings
- product update price and sale_price(b)
- Icon picker(n)
- admin what about delete modal success messages (no need just close)(b)
- need to fix confirmation-modal button (a)
- user dropdown design issue(a)
- route protection && already logged in redirect(b)
- types list update on create not working (we could use cache policy here)(b)
- Category Icon at List(n)
- Category Console warning(n)
- Loader(a)
- ErrorMessage design(a)
- Order list need to check shipping address format(b)
- status should have color code(b/a)
- order status server errors (cleaning issues)(b)
- need to discussion about settings (use context) (N)
- profile save button should place outside(a)
- need to check profile avatar data(b)+me query update check
- need to fix sidebar icons(a)
- layout header data(avatar)(b)
- server env fix(b)
- type icon
- coupon datetime validation
- should create a routes file
- dashboard latest order and popular order
- over all order process like refund , order edit , cancel
